package com.example.spring_react_result;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringReactResultApplicationTests {

	@Test
	void contextLoads() {
	}

}
